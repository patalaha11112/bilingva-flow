'use client'

import Link from 'next/link'
import { ChevronRight, BookOpen, MessageSquare, PenLine, Video } from 'lucide-react'
import type { InterfaceLang, LearningLang, Level } from '@/types/database'
import { t } from '@/lib/i18n'

interface HomeTopSectionProps {
  lang: InterfaceLang
  learningLang: LearningLang
  level: Level
  stats: {
    sentences_completed: number
    dialogs_completed: number
    essays_completed: number
    videos_completed: number
  }
}

export function HomeTopSection({ lang, learningLang, level, stats }: HomeTopSectionProps) {
  return (
    <section className="flex gap-3">

      {/* Левая карточка — язык + уровень */}
      <div className="flex-1 rounded-2xl bg-card p-4 shadow-sm flex flex-col justify-between gap-3">
        <div>
          <p className="text-xs text-muted-foreground mb-0.5">{t('learningLanguage', lang)}</p>
          <p className="text-base font-semibold">
            {learningLang === 'es' ? '🇪🇸' : '🇺🇸'} {t(learningLang === 'es' ? 'lang_es' : 'lang_en', lang)}
          </p>
        </div>

        <div>
          <p className="text-xs text-muted-foreground mb-0.5">{t('yourLevel', lang)}</p>
          <p className="text-4xl font-black tracking-tight leading-none">{level}</p>
        </div>

        <Link
          href="/settings"
          className="flex items-center gap-0.5 text-xs text-muted-foreground hover:text-foreground transition-colors w-fit"
        >
          {t('change', lang)} <ChevronRight className="h-3 w-3" />
        </Link>
      </div>

      {/* Правая карточка — статы */}
      <div className="flex-1 rounded-2xl bg-card p-4 shadow-sm flex flex-col justify-between gap-2">
        <StatRow icon={<BookOpen className="h-3.5 w-3.5 text-[var(--ring-blue)]" />} label={t('sentences_stat', lang)} value={stats.sentences_completed} />
        <StatRow icon={<MessageSquare className="h-3.5 w-3.5 text-[var(--ring-green)]" />} label={t('dialogs_stat', lang)} value={stats.dialogs_completed} />
        <StatRow icon={<PenLine className="h-3.5 w-3.5 text-muted-foreground" />} label={t('essays_stat', lang)} value={stats.essays_completed} />
        <StatRow icon={<Video className="h-3.5 w-3.5 text-[var(--ring-orange)]" />} label={t('videos_stat', lang)} value={stats.videos_completed} />
      </div>

    </section>
  )
}

function StatRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <div className="flex items-center gap-1.5">
        {icon}
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <span className="text-sm font-semibold tabular-nums">{value}</span>
    </div>
  )
}
